using Microsoft.AspNetCore.Mvc.Testing;
using Serilog;
using System.Net.Http.Json;
using WebApi_Emissor_Senha;
using Xunit;
using Serilog;
using Serilog.Sinks.File;
using WebApi_Emissor_Senha;


public partial class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);
        var userDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        var logFilePath = Path.Combine(userDirectory, "Documents", "Logs", "app-.log");

        // Logs
        Log.Logger = new LoggerConfiguration()
            .WriteTo.Console()
            .WriteTo.File(logFilePath, rollingInterval: RollingInterval.Day)
            .CreateLogger();

        builder.Host.UseSerilog();

        //servicos
        builder.Services.AddControllers();
        builder.Services.AddHostedService<SenhaBackgroundService>();

        var app = builder.Build();

        app.MapControllers();

        app.Run();
    }
}


public class SenhaControllerTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public SenhaControllerTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory;
    }

    [Fact]
    public async Task TestEmitirSenha()
    {
        var client = _factory.CreateClient();
        var response = await client.PostAsync("/senha/emitir", null);
        response.EnsureSuccessStatusCode();

        var senha = await response.Content.ReadFromJsonAsync<Senha>();
        Assert.NotNull(senha);
        Assert.Equal("Ativa", senha.Status);
    }

    [Fact]
    public async Task TestFinalizarSenha()
    {
        var client = _factory.CreateClient();
        var response = await client.PostAsync("/senha/emitir", null);
        response.EnsureSuccessStatusCode();

        var senha = await response.Content.ReadFromJsonAsync<Senha>();
        var finalizarResponse = await client.PostAsync($"/senha/finalizar/{senha.Id}", null);
        finalizarResponse.EnsureSuccessStatusCode();

        var senhaFinalizada = await finalizarResponse.Content.ReadFromJsonAsync<Senha>();
        Assert.Equal("Finalizada", senhaFinalizada.Status);
    }

    [Fact]
    public async Task TestCancelarSenha()
    {
        var client = _factory.CreateClient();
        var response = await client.PostAsync("/senha/cancelar", null);
        response.EnsureSuccessStatusCode();

        var senha = await response.Content.ReadFromJsonAsync<Senha>();
        var cancelarResponse = await client.PostAsync($"/senha/cancelar/{senha.Id}", null);
        cancelarResponse.EnsureSuccessStatusCode();

        var senhaCancelada = await cancelarResponse.Content.ReadFromJsonAsync<Senha>();
        Assert.Equal("Cancelada", senhaCancelada.Status);
    }
}

public class Senha
{
    public int Id { get; set; }
    public string Codigo { get; set; }
    public DateTime DataEmissao { get; set; }
    public DateTime? DataFinalizacao { get; set; }
    public string Status { get; set; }
    public string InformacaoExtra { get; set; }
}

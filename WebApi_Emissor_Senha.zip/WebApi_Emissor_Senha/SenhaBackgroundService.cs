using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using WebApi_Emissor_Senha.Controllers;

namespace WebApi_Emissor_Senha
{
    public class SenhaBackgroundService : BackgroundService
    {
        private readonly ILogger<SenhaBackgroundService> _logger;
        private readonly TimeSpan _intervaloVerificacao = TimeSpan.FromMinutes(1);
        private readonly TimeSpan _tempoLimite = TimeSpan.FromMinutes(5); // 5 minutinhos para cancelar

        public SenhaBackgroundService(ILogger<SenhaBackgroundService> logger)
        {
            _logger = logger;
        }

        //Cancelando a senha
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                VerificarSenhas();
                await Task.Delay(_intervaloVerificacao, stoppingToken);
            }
        }

        private void VerificarSenhas()
        {
            var agora = DateTime.Now;
            foreach (var senha in SenhaController.senhas.Where(s => s.Status == "Ativa"))
            {
                if (agora - senha.DataEmissao > _tempoLimite)
                {
                    senha.DataCanceladaManual = DateTime.Now;
                    senha.Status = "Cancelada";
                    _logger.LogInformation($"Senha cancelada automaticamente: {senha.Codigo}");
                }
            }
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Text.Json;


namespace WebApi_Emissor_Senha.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SenhaController : ControllerBase
    {
        public static List<Senha> senhas = new List<Senha>();
        private readonly ILogger<SenhaController> _logger;

        public SenhaController(ILogger<SenhaController> logger)
        {
            _logger = logger;
        }

        [HttpPost("emitir")]
        public async Task<IActionResult> EmitirSenha()
        {
            var senha = new Senha
            {
                Id = senhas.Count + 1,
                Codigo = Guid.NewGuid().ToString(),
                DataEmissao = DateTime.Now,
                Status = "Ativa",
                InformacaoExtra = await ObterInformacaoExtra()
            };

            senhas.Add(senha);
            _logger.LogInformation($"Senha emitida: {senha.Codigo}");
            return Ok(senha);
        }

        [HttpPost("finalizar/{id}")]
        public IActionResult FinalizarSenha(int id)
        {
            var senha = senhas.FirstOrDefault(s => s.Id == id);
            if (senha == null || senha.Status != "Ativa")
            {
                return NotFound();
            }

            senha.DataFinalizacao = DateTime.Now;
            senha.Status = "Finalizada";
            _logger.LogInformation($"Senha finalizada: {senha.Codigo}");
            return Ok(senha);
        }

        [HttpPost("cancelar/{id}")]
        public IActionResult CancelarSenha(int id)
        {
            var senha = senhas.FirstOrDefault(s => s.Id == id);
            if (senha == null || senha.Status != "Ativa")
            {
                return NotFound();
            }

            senha.DataCanceladaManual = DateTime.Now;
            senha.Status = "Cancelada manualmente";
            _logger.LogInformation($"Senha Cancelada manualmente : {senha.Codigo}");
            return Ok(senha);
        }

        [HttpGet("listar")]
        public IActionResult ListarSenhas()
        {
            return Ok(senhas);
        }

        private async Task<string> ObterInformacaoExtra()
        {
            using var client = new HttpClient();
            var response = await client.GetStringAsync("https://api.chucknorris.io/jokes/random");
            var jsonDocument = JsonDocument.Parse(response);
            return jsonDocument.RootElement.GetProperty("value").GetString();
        }

    }
}


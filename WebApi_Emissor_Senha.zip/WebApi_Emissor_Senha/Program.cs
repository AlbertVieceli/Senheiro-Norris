﻿using Serilog;
using Serilog.Sinks.File;
using WebApi_Emissor_Senha;


var builder = WebApplication.CreateBuilder(args);
var userDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
var logFilePath = Path.Combine(userDirectory, "Documents", "Logs", "app-.log");

//logs
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File(logFilePath, rollingInterval: RollingInterval.Day)
    .CreateLogger();

builder.Host.UseSerilog();

builder.Services.AddControllers();
builder.Services.AddHostedService<SenhaBackgroundService>();

var app = builder.Build();

app.MapControllers();

app.Run();


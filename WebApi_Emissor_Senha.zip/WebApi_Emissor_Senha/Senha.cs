namespace WebApi_Emissor_Senha
{
    public class Senha
    {
        public int Id { get; set; }
        public string Codigo { get; set; }
        public DateTime DataEmissao { get; set; }
        public DateTime? DataFinalizacao { get; set; }
        public DateTime? DataCanceladaManual { get; set; }
        public string Status { get; set; } // Ativo, Finalizado, Cancelada
        public string InformacaoExtra { get; set; }
    }
}
